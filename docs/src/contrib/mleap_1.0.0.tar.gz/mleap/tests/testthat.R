library(testthat)
library(mleap)

test_check("mleap")
