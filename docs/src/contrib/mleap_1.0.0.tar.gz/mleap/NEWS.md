# mleap 1.0.0

* **Breaking change**: `ml_write_bundle()` now takes the `sample_input` instead of `dataset`.
* Support for Spark 2.4 and MLeap 0.14.
* Integer inputs are now supported (#36).

# mleap 0.1.3

* Support MLeap 0.12.0.

# mleap 0.1.2

* Support MLeap 0.10.1 and Spark 2.3.0.

# mleap 0.1.1

* Allow heterogenous inputs (`numeric` and `character`) in `mleap_transform()` (#16).
